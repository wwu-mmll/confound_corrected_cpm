# Edge Selection

::: cpm.edge_selection