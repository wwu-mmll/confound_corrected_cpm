```python
--8<-- "examples/example_simulated_data.py"
```