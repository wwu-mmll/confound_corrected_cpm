```python
--8<-- "examples/hcp_analysis.py"
```